# Sparkfined Landing Page

Professional landing page for Sparkfined - Crypto trading analytics platform.

## 🚀 Tech Stack

- **Framework**: React 18 + TypeScript
- **Build Tool**: Vite
- **Animations**: Framer Motion
- **Deployment**: Vercel
- **Domain**: sparkfined.xyz

## 📦 Project Structure

```
sparkfined-landing/
├── src/
│   ├── components/
│   │   ├── sections/
│   │   │   ├── Hero.tsx
│   │   │   ├── DemoChart.tsx
│   │   │   ├── ProblemSolution.tsx
│   │   │   ├── DemoReplay.tsx
│   │   │   ├── Progression.tsx
│   │   │   ├── DemoSignal.tsx
│   │   │   ├── Architecture.tsx
│   │   │   ├── SocialProof.tsx
│   │   │   ├── FAQ.tsx
│   │   │   └── CTA.tsx
│   │   └── ui/
│   │       ├── Button.tsx
│   │       └── ...
│   ├── styles/
│   │   └── global.css
│   ├── App.tsx
│   └── main.tsx
├── public/
│   └── assets/
├── vercel.json
└── package.json
```

## 🛠️ Setup

### Installation
```bash
npm install
```

### Development
```bash
npm run dev
```

Server läuft auf http://localhost:5173

### Build
```bash
npm run build
```

### Preview
```bash
npm run preview
```

## 🌐 Deployment

### Vercel Setup

1. **Login to Vercel**
```bash
npm i -g vercel
vercel login
```

2. **Deploy to Production**
```bash
vercel --prod
```

3. **Custom Domain Setup (sparkfined.xyz)**
- Gehe zu Vercel Dashboard
- Projekt auswählen
- Settings → Domains
- Add Domain: `sparkfined.xyz`
- DNS Settings bei deinem Domain Provider:
  ```
  Type: A
  Name: @
  Value: 76.76.21.21
  
  Type: CNAME
  Name: www
  Value: cname.vercel-dns.com
  ```

## 🎨 Design System

### Colors
- Background: `#0A0E1A` (Deep space)
- Surface: `#141927` (Elevated panels)
- Primary: `#00F5FF` (Cyan - CTAs)
- Success: `#00DD88` (Green - Positive)
- Warning: `#FFA500` (Orange - Caution)
- Error: `#FF4444` (Red - Negative)

## 🔮 Easter Eggs

- Ghost glow effects (333ms timing)
- Alchemical symbols (5% opacity)
- Color progression (lead → gold)
- Phase number math (1+2+3+4=10→1)

## 📊 Performance Targets

- First Contentful Paint: < 1.5s
- Time to Interactive: < 3.0s
- Lighthouse Score: 95+

## 🔗 Links

- **Production**: https://sparkfined.xyz
- **GitHub**: https://github.com/baum777/sparkfined-landing

## 📄 License

Private - © 2024 Sparkfined
